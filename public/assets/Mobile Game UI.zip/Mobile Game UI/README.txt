This UI Pack includes 9 buttons and 10 icons in PNG format, all UI elements were created in Photoshop. Designed UI designer by Lukas Tomasek.

You can use them for commercial purposes
You can not resell them as stand alone product
You don't have to give me credit for the product , but if you do contact me I would like to see the game :)

All rights to UI pack are reserved;


contact info : 
email : silentthievesstudio@gmail.com
	